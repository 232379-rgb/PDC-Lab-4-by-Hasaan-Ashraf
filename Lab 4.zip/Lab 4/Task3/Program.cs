﻿using System;
using System.Threading;

class Program
{
    const int NumThreads = 4;
    const int IncrementsPerThread = 250_000;

    // Shared counter
    static long counter = 0;

    // Lock object
    static readonly object counterLock = new object();

    static void Worker()
    {
        for (int i = 0; i < IncrementsPerThread; i++)
        {
            // Lock ONLY the counter++ statement
            lock (counterLock)
            {
                counter++;
            }
        }
    }

    static void Main()
    {
        Thread[] threads = new Thread[NumThreads];

        // Create and start threads
        for (int t = 0; t < NumThreads; t++)
        {
            threads[t] = new Thread(Worker);
            threads[t].Start();
        }

        // Wait for all threads to finish
        foreach (Thread thread in threads)
        {
            thread.Join();
        }

        // Calculate expected total
        long total = (long)NumThreads * IncrementsPerThread;

        Console.WriteLine("====================================");
        Console.WriteLine("MutexFix - Thread Synchronization");
        Console.WriteLine("====================================");
        Console.WriteLine($"Number of threads: {NumThreads}");
        Console.WriteLine($"Increments per thread: {IncrementsPerThread}");
        Console.WriteLine($"Expected counter: {total}");
        Console.WriteLine($"Final counter: {counter}");
        Console.WriteLine($"Lost updates: {total - counter}");
        
    }
}